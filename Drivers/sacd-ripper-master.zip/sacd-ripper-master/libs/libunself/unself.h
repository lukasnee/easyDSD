#ifndef UNSELF_H__
#define UNSELF_H__

int unself(const char *file_in, const char *file_out);

#endif /* UNSELF_H__ */
